# UnifiedFloppyTool - Architektur-Analyse

**Erstellt:** Januar 2025  
**Status:** Deep-Dive Analyse  
**Projekt-Größe:** ~64,000 Zeilen (25,842 C + 38,313 H)

---

## 1. ZENTRALE DATENMODELLE

### 1.1 Hierarchie der Datenstrukturen

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           DATA MODEL HIERARCHY                                  │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                         ImageContainer                                   │   │
│  │  ┌─────────────────────────────────────────────────────────────────┐   │   │
│  │  │                     uft_disk_t (Core)                            │   │   │
│  │  │  • path, format, flags                                          │   │   │
│  │  │  • geometry (uft_geometry_t)                                    │   │   │
│  │  │  • read_only, modified                                          │   │   │
│  │  │  • plugin_data (format-spezifisch)                              │   │   │
│  │  │  • track_cache[]                                                │   │   │
│  │  └─────────────────────────────────────────────────────────────────┘   │   │
│  │                                  │                                      │   │
│  │  ┌─────────────────────────────────────────────────────────────────┐   │   │
│  │  │                     flux_disk_t (Flux)                          │   │   │
│  │  │  • max_cylinders, max_heads                                     │   │   │
│  │  │  • tracks[] (flux_track_t**)                                    │   │   │
│  │  │  • format (DISK_FORMAT_*)                                       │   │   │
│  │  │  • total_size_bytes, overall_quality                            │   │   │
│  │  └─────────────────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                      │                                         │
│  ┌───────────────────────────────────┴───────────────────────────────────┐     │
│  │                              Track                                     │     │
│  │  ┌──────────────────────────┐    ┌──────────────────────────────┐    │     │
│  │  │   uft_track_t (Core)     │    │   flux_track_t (Flux)        │    │     │
│  │  │  • cylinder, head        │    │  • cylinder, head            │    │     │
│  │  │  • sectors[]             │    │  • flux_samples[]            │    │     │
│  │  │  • flux[] (optional)     │    │  • bitstream                 │    │     │
│  │  │  • raw_data[]            │    │  • quality_score             │    │     │
│  │  │  • encoding              │    │  • encoding                  │    │     │
│  │  │  • metrics               │    │  • num_revolutions           │    │     │
│  │  └──────────────────────────┘    └──────────────────────────────┘    │     │
│  └───────────────────────────────────────────────────────────────────────┘     │
│                                      │                                         │
│  ┌───────────────────────────────────┴───────────────────────────────────┐     │
│  │                              Sector                                    │     │
│  │  ┌──────────────────────────────────────────────────────────────────┐│     │
│  │  │                      uft_sector_t                                 ││     │
│  │  │  • id (uft_sector_id_t: C/H/R/N, CRC)                            ││     │
│  │  │  • data[], data_size                                             ││     │
│  │  │  • data_crc, status (Flags)                                      ││     │
│  │  │  • bit_position, gap_before (Timing)                             ││     │
│  │  └──────────────────────────────────────────────────────────────────┘│     │
│  └───────────────────────────────────────────────────────────────────────┘     │
│                                      │                                         │
│  ┌───────────────────────────────────┴───────────────────────────────────┐     │
│  │                           FluxStream                                   │     │
│  │  ┌─────────────────────────┐    ┌─────────────────────────────────┐  │     │
│  │  │  flux_bitstream_t       │    │   Raw Flux (in Track)           │  │     │
│  │  │  • bits[]               │    │  • uint32_t* flux               │  │     │
│  │  │  • bit_count            │    │  • flux_count                   │  │     │
│  │  │  • encoding             │    │  • flux_tick_ns                 │  │     │
│  │  │  • sync_patterns_found  │    │                                 │  │     │
│  │  │  • decode_errors        │    │                                 │  │     │
│  │  └─────────────────────────┘    └─────────────────────────────────┘  │     │
│  └───────────────────────────────────────────────────────────────────────┘     │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 Datenmodell-Probleme

| Problem | Beschreibung | Schweregrad |
|---------|--------------|-------------|
| **Duale Disk-Strukturen** | `uft_disk_t` vs `flux_disk_t` - keine einheitliche Abstraktion | 🔴 Hoch |
| **Track-Redundanz** | `uft_track_t.flux[]` UND `flux_track_t.flux_samples[]` | 🟡 Mittel |
| **Fehlende FluxStream-Kapselung** | Flux-Daten direkt in Track, nicht als eigenständiges Objekt | 🟡 Mittel |
| **plugin_data void*** | Keine Typsicherheit für Format-spezifische Daten | 🟡 Mittel |

---

## 2. SCHICHTEN-ARCHITEKTUR (IST-ZUSTAND)

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              CURRENT LAYERS                                     │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                              GUI LAYER                                  │   │
│   │  gui/forms/mainwindow.ui                                               │   │
│   │  include/uft/gui/*.h (uft_format_info_widget.h)                        │   │
│   │                                                                         │   │
│   │  ⚠️ PROBLEM: Business Logic in GUI Header (decode/parse functions)     │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                      │                                         │
│                                      ▼                                         │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                            CORE LAYER                                   │   │
│   │  src/core/uft_core.c (856 Zeilen)                                      │   │
│   │  src/core/uft_format_plugin.c                                          │   │
│   │  src/core/uft_cache.c                                                  │   │
│   │                                                                         │   │
│   │  ⚠️ PROBLEM: MFM/GCR Decoder in Core (sollte in decoders/)             │   │
│   │  ⚠️ PROBLEM: flux_core.c in core/ (Schichten-Vermischung)              │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│          │                           │                          │              │
│          ▼                           ▼                          ▼              │
│   ┌──────────────┐    ┌──────────────────────┐    ┌────────────────────┐       │
│   │  FORMATS     │    │     DECODERS         │    │    HARDWARE        │       │
│   │  26 Plugins  │    │  src/decoders/       │    │  src/hardware/     │       │
│   │              │    │  + src/core/uft_mfm* │    │                    │       │
│   │  ✅ Sauber   │    │  ⚠️ Fragmentiert    │    │  ✅ Sauber         │       │
│   └──────────────┘    └──────────────────────┘    └────────────────────┘       │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 2.1 Grenzprobleme

#### ✅ SAUBER GETRENNT:
- **Hardware ↔ Formats**: Keine direkten Aufrufe
- **Hardware ↔ Core**: Klare uft_hw_* API
- **Core ↔ Formats**: Plugin-System funktioniert

#### ⚠️ VERMISCHT:
| Wo | Was | Problem |
|----|-----|---------|
| `src/core/uft_mfm_*.c` | MFM Encoder/Decoder | Gehört nach `src/decoders/` |
| `src/core/flux_core.c` | Flux-Handling | Gehört nach `src/flux/` |
| `src/core/uft_pll.c` | PLL-Logik | Gehört nach `src/decoders/` |
| `include/uft/gui/uft_format_info_widget.h` | Parsing-Code | Gehört nach Core |
| `src/uft_gui_params_extended.c` | Im Root statt gui/ | Falsche Location |

---

## 3. GOD-MODULE ANALYSE

### 3.1 Kandidaten für Splitting

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                           GOD-MODULE REPORT                                   ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  🔴 KRITISCH (>1000 Zeilen, >30 Funktionen, Multiple Responsibilities)       ║
║  ═══════════════════════════════════════════════════════════════════════════ ║
║                                                                               ║
║  1. uft_forensic_imaging.c (1129 Zeilen, 32 Funktionen)                      ║
║     ├── CPU Capabilities Detection                                           ║
║     ├── SIMD find_nonzero (C/SSE2/AVX2)                                     ║
║     ├── File I/O Helpers                                                     ║
║     ├── Job Management                                                       ║
║     ├── Hashing (MD5/SHA256)                                                ║
║     ├── Split-File Handling                                                  ║
║     ├── Bad Sector Tracking                                                  ║
║     └── Execution Engine                                                     ║
║                                                                               ║
║     SPLIT INTO:                                                              ║
║     • uft_fi_cpu.c       (CPU Detection)                                     ║
║     • uft_fi_simd.c      (SIMD find_nonzero)                                 ║
║     • uft_fi_job.c       (Job Management)                                    ║
║     • uft_fi_hash.c      (Hashing)                                           ║
║     • uft_fi_split.c     (Split Files)                                       ║
║     • uft_fi_exec.c      (Execution)                                         ║
║                                                                               ║
║  ─────────────────────────────────────────────────────────────────────────── ║
║                                                                               ║
║  2. uft_gui_params_extended.h (631 Zeilen)                                   ║
║     15 typedef structs + 4 enums - "Kitchen Sink" Header                     ║
║                                                                               ║
║     SPLIT INTO:                                                              ║
║     • uft_gui_geometry.h     (Geometry Settings)                             ║
║     • uft_gui_timing.h       (MFM Timing)                                    ║
║     • uft_gui_processing.h   (Adaptive Processing)                           ║
║     • uft_gui_forensics.h    (Forensic Settings)                             ║
║                                                                               ║
║  ─────────────────────────────────────────────────────────────────────────── ║
║                                                                               ║
║  3. uft_format_variants.h (829 Zeilen)                                       ║
║     Enthält ALLE Format-Varianten als Inline-Daten                           ║
║                                                                               ║
║     REFACTOR:                                                                ║
║     • Varianten als separate .c mit externen Tabellen                        ║
║     • Lazy-Loading statt statischer Arrays                                   ║
║                                                                               ║
║  ─────────────────────────────────────────────────────────────────────────── ║
║                                                                               ║
║  🟡 BEOBACHTEN (500-1000 Zeilen, Multiple Concerns)                          ║
║  ═══════════════════════════════════════════════════════════════════════════ ║
║                                                                               ║
║  4. uft_fm_decoder.c (944 Zeilen)                                            ║
║     FM Decoding + CRC + Sector Extraction - Akzeptabel als Decoder-Unit      ║
║                                                                               ║
║  5. uft_core.c (856 Zeilen, 33 Funktionen)                                   ║
║     Disk/Track/Sector Operations + Init + Conversion - Am Limit              ║
║     Candidate Split: uft_convert.c herauslösen                               ║
║                                                                               ║
║  6. uft_hw_greaseweazle.c (705 Zeilen)                                       ║
║     Alles GW-spezifisch - OK für einzelnen Hardware-Driver                   ║
║                                                                               ║
║  7. uft_hardware.c (704 Zeilen)                                              ║
║     Backend Registration + High-Level API - OK für Facade                    ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

---

## 4. EMPFOHLENE ZIEL-ARCHITEKTUR

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          TARGET ARCHITECTURE                                    │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                              GUI LAYER                                  │   │
│   │  • Qt Widgets / QML                                                    │   │
│   │  • ViewModels (Adapter zum Core)                                       │   │
│   │  • KEINE Business Logic                                                │   │
│   └───────────────────────────────────┬─────────────────────────────────────┘   │
│                                       │                                         │
│                                       ▼                                         │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                         APPLICATION LAYER                               │   │
│   │  • Use Cases (ReadDisk, WriteDisk, Convert, Analyze)                   │   │
│   │  • Workflow Orchestration                                              │   │
│   │  • Progress Reporting                                                  │   │
│   └───────────────────────────────────┬─────────────────────────────────────┘   │
│                                       │                                         │
│   ┌───────────────────────────────────┴─────────────────────────────────────┐   │
│   │                           DOMAIN LAYER                                  │   │
│   │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐   │   │
│   │  │   Disk      │  │   Track     │  │   Sector    │  │   Flux      │   │   │
│   │  │  (Entity)   │  │  (Entity)   │  │  (Entity)   │  │  (Stream)   │   │   │
│   │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘   │   │
│   │                                                                         │   │
│   │  ┌─────────────────────────────────────────────────────────────────┐   │   │
│   │  │                    Unified Image Container                       │   │
│   │  │  • Kombiniert uft_disk_t + flux_disk_t                          │   │
│   │  │  • Einheitlicher Zugriff auf Sektor- und Flux-Daten             │   │
│   │  └─────────────────────────────────────────────────────────────────┘   │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                       │                                         │
│   ┌───────────────────────────────────┼─────────────────────────────────────┐   │
│   │                       INFRASTRUCTURE LAYER                              │   │
│   │       ┌───────────────┬───────────┴───────────┬───────────────┐        │   │
│   │       ▼               ▼                       ▼               ▼        │   │
│   │  ┌─────────┐    ┌─────────┐           ┌─────────────┐   ┌─────────┐   │   │
│   │  │ Formats │    │Decoders │           │  Hardware   │   │  Utils  │   │   │
│   │  │ 26      │    │ MFM/FM  │           │  Adapters   │   │  CRC    │   │   │
│   │  │ Plugins │    │ GCR     │           │  GW/KF/FC   │   │  SIMD   │   │   │
│   │  │         │    │ PLL     │           │  SC/OCM     │   │  Hash   │   │   │
│   │  └─────────┘    └─────────┘           └─────────────┘   └─────────┘   │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. REFACTORING-PLAN

### Phase 1: God-Module aufbrechen (1-2 Wochen)

```bash
# 1. Forensic Imaging aufteilen
src/forensic/
├── uft_fi_cpu.c         # CPU Detection
├── uft_fi_simd.c        # SIMD Operations  
├── uft_fi_job.c         # Job Management
├── uft_fi_hash.c        # Hashing
├── uft_fi_split.c       # Split Files
├── uft_fi_exec.c        # Execution Engine
└── uft_forensic.h       # Unified Header

# 2. GUI Params aufteilen
include/uft/gui/
├── uft_gui_geometry.h
├── uft_gui_timing.h
├── uft_gui_processing.h
└── uft_gui_forensics.h
```

### Phase 2: Decoder konsolidieren (1 Woche)

```bash
# Alle Decoder an einem Ort
src/decoders/
├── mfm/
│   ├── uft_mfm_decoder.c
│   ├── uft_mfm_avx2.c
│   ├── uft_mfm_sse2.c
│   └── uft_mfm_scalar.c
├── fm/
│   └── uft_fm_decoder.c
├── gcr/
│   └── uft_gcr_decoder.c
├── pll/
│   ├── uft_pll.c
│   └── uft_dpll_wd1772.c
└── uft_decoder_plugin.c
```

### Phase 3: Unified Image Container (2-3 Wochen)

```c
// NEU: Einheitlicher Container
typedef struct uft_image {
    // Basis-Info
    char*               path;
    uft_format_t        format;
    uft_geometry_t      geometry;
    
    // Sektor-Ebene (decoded)
    uft_track_t**       tracks;
    size_t              track_count;
    
    // Flux-Ebene (raw)  
    uft_flux_stream_t** flux_streams;  // Optional
    size_t              flux_count;
    
    // Plugin
    const uft_format_plugin_t* plugin;
    void*               plugin_data;
    
    // State
    uint32_t            flags;
    bool                modified;
} uft_image_t;
```

### Phase 4: Layer Cleanup (1 Woche)

1. `flux_core.c` → `src/flux/`
2. Business Logic aus GUI-Headers entfernen
3. `uft_gui_params_extended.c` → `src/gui/`

---

## 6. METRIKEN (Vorher/Nachher)

| Metrik | Vorher | Nachher (Ziel) |
|--------|--------|----------------|
| Max. Datei-Größe | 1129 Zeilen | <500 Zeilen |
| Max. Funktionen/Datei | 33 | <20 |
| Zirkuläre Deps | 2 | 0 |
| Layer Violations | 5 | 0 |
| Duale Datenmodelle | 2 | 1 (Unified) |
| Coverage God-Modules | 0% | >80% |

---

## 7. NÄCHSTE SCHRITTE

1. **Sofort**: God-Module dokumentieren (TODOs einfügen)
2. **Woche 1**: `uft_forensic_imaging.c` aufteilen
3. **Woche 2**: Decoder konsolidieren
4. **Woche 3-4**: Unified Image Container implementieren
5. **Woche 5**: Layer Cleanup + Tests

---

*Analyse erstellt mit Claude - Januar 2025*
