#pragma once
#include "flux_format/flux_format.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const fluxfmt_plugin_t fluxfmt_d80_plugin;

#ifdef __cplusplus
}
#endif
